# Experiment 10 - Network Troubleshooting with Wireshark and CLI

Cisco CLI configuration and verification files extracted from the supplied NRSIP Lab Manual. Formatting has been cleaned so commands can be copied into Packet Tracer/GNS3 consoles.

## Files
- `Router1.cfg`
- `Router2.cfg`
- `VPCS_IP_Configuration.txt`
- `verification.txt`
- `wireshark_filters.txt`

> Packet Tracer `.pkt` and GNS3 project files are not included; this repository contains the source/configuration commands from the manual.
