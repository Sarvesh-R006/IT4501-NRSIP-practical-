# NRSIP Lab Experiments

Source/configuration files for the IT4501 Network Routing, Switching & Internet Protocol Lab Manual.

## Experiments

1. VLAN Configuration and Inter-VLAN Routing
2. STP Verification and Root Bridge Election
3. IPv4 Subnetting and VLSM Design
4. IPv6 Configuration and SLAAC
5. Static and Default Route Configuration
6. VLAN Configuration and Inter-VLAN Routing
7. OSPF Single-Area Configuration
8. EIGRP Configuration and Verification
9. NAT and PAT Configuration
10. Network Troubleshooting with Wireshark and CLI

## Tools

- Cisco Packet Tracer
- GNS3
- Wireshark

The files are organized one experiment per folder. `.cfg` files contain Cisco CLI configuration commands, while `.txt` files contain host addressing, verification commands, or Wireshark filters.

## Source

Based on the supplied `NRSIP_LAB_MANUAL.pdf` (IT4501).
