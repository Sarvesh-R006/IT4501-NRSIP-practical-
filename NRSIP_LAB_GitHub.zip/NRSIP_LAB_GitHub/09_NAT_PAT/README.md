# Experiment 9 - NAT and PAT Configuration

Cisco CLI configuration and verification files extracted from the supplied NRSIP Lab Manual. Formatting has been cleaned so commands can be copied into Packet Tracer/GNS3 consoles.

## Files
- `Router1_Dynamic_NAT.cfg`
- `Router1_PAT_Overload.cfg`
- `PC_Server_IP_Configuration.txt`
- `verification.txt`

> Packet Tracer `.pkt` and GNS3 project files are not included; this repository contains the source/configuration commands from the manual.
