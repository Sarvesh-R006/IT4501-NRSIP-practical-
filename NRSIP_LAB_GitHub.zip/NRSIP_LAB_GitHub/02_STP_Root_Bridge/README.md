# Experiment 2 - STP Verification and Root Bridge Election

Cisco CLI configuration and verification files extracted from the supplied NRSIP Lab Manual. Formatting has been cleaned so commands can be copied into Packet Tracer/GNS3 consoles.

## Files
- `S1_Root_Bridge.cfg`
- `S2.cfg`
- `S3.cfg`
- `PC_IP_Configuration.txt`
- `verification.txt`

> Packet Tracer `.pkt` and GNS3 project files are not included; this repository contains the source/configuration commands from the manual.
